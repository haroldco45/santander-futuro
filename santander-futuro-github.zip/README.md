# Santander, nuestro futuro

App de Vibras Positivas HM con todo sobre Santander (Cantabria, España): lugares, barrios, costos, cómo emigrar desde Colombia y plan paso a paso.

Dirección: https://haroldco45.github.io/santander-futuro/

## Publicar en GitHub Pages
1. Cree el repositorio público `santander-futuro` en la cuenta `haroldco45`.
2. Suba todos los archivos a la raíz, incluido `.nojekyll`.
3. Settings → Pages → rama `main`, carpeta `/ (root)` → Save.
4. Espere un par de minutos y abra la dirección.

## Actualizar
- Al cambiar `index.html`, suba `santander-v1` a `santander-v2` en `sw.js` para que los celulares carguen la versión nueva.
- Si cambia `og-image.png`, suba `?v=1` a `?v=2` en `index.html` para que WhatsApp muestre la imagen nueva.
- Si usa otro nombre de repositorio, cambie la dirección en las etiquetas `og:` de `index.html`.

## Archivos
- `index.html` — la app completa
- `manifest.webmanifest`, `sw.js` — instalación en el celular y uso sin señal
- `icon-*.png`, `apple-touch-icon.png` — íconos
- `og-image.png` — vista previa al compartir por WhatsApp (1200×630)

Corte de la información: 27 de septiembre de 2026, hora de Colombia.
